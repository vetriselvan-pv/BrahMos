import { Component } from '@angular/core';
import { CdkDragDrop, copyArrayItem } from '@angular/cdk/drag-drop';
import { IMenuList } from '@brahmos/studio-modal';

@Component({
    selector: 'db-menu-bar',
    templateUrl: './menu-bar.component.html',
    styleUrls: ['./menu-bar.component.scss'],
})
export class MenuBarComponent {
  menuList : IMenuList[] = [{
    heading : 'Components',
    options : [
      {
        hoverText : 'Text Box',
        icon : './assets/svg/Textbox.svg',
        placeholder : 'Text Box',
        tagName : 'textbox',
        uId : '01'
      },
      {
        hoverText : 'Checkbox',
        icon : './assets/svg/Checkbox.svg',
        placeholder : 'Checkbox',
        tagName : 'checkbox',
        uId : '02'
      },
      {
        hoverText : 'Number',
        icon : './assets/svg/Number.svg',
        placeholder : 'Number',
        tagName : 'number',
        uId : '03'
      },
      {
        hoverText : 'Password',
        icon : './assets/svg/Password.svg',
        placeholder : 'Password',
        tagName  : 'password',
        uId : '04'
      },
      {
        hoverText : 'Email',
        icon : './assets/svg/Email.svg',
        placeholder : 'Email',
        tagName : 'email',
        uId : '05'
      },
      {
        hoverText : 'Color',
        icon : './assets/svg/Color.svg',
        placeholder : 'Color',
        tagName : 'color',
        uId : '06'
      }
    ]
  },
{
  heading : 'Html Elements',
  options : [
    {
      hoverText : 'Div',
      icon :'./assets/svg/Div.svg',
      placeholder : 'Div',
      tagName : 'div',
      uId : '11'

    },
    {
      hoverText : 'Heading 1',
      icon :'./assets/svg/Heading 1.svg',
      placeholder : 'H1',
      tagName : 'h1',
      uId : '12'
    },
    {
      hoverText : 'Heading 2',
      icon :'./assets/svg/Heading 2.svg',
      placeholder : 'H2',
      tagName : 'h2',
      uId : '13'
    },
    {
      hoverText : 'Heading 3',
      icon :'./assets/svg/Heading 3.svg',
      placeholder : 'H3',
      tagName : 'h3',
      uId : '14'
    },
    {
      hoverText : 'Heading 4',
      icon :'./assets/svg/Heading 4.svg',
      placeholder : 'H4',
      tagName : 'h4',
      uId : '15'
    },
    {
      hoverText : 'Heading 5',
      icon :'./assets/svg/Heading 5.svg',
      placeholder : 'H5',
      tagName : 'h5',
      uId : '16'
    },
    {
      hoverText : 'Heading 6',
      icon :'./assets/svg/Heading 6.svg',
      placeholder : 'H6',
      tagName : 'h6',
      uId : '17'
    },
    {
      hoverText : 'Span',
      icon :'./assets/svg/Span.svg',
      placeholder : 'Span',
      tagName : 'span',
      uId : '18'
    },
    {
      hoverText : 'Paragraph',
      icon :'./assets/svg/Paragraph.svg',
      placeholder : 'Paragraph',
      tagName : 'paragraph',
      uId : '19'
    },
    {
      hoverText : 'Break',
      icon :'./assets/svg/Break.svg',
      placeholder : 'Break',
      tagName : 'break',
      uId : '110'
    },
    // {
    //   hoverText : 'List',
    //   icon :'./assets/svg/list.svg',
    //   placeholder : 'List'
    // },
    // {
    //   hoverText : 'Image',
    //   icon : './assets/svg/image.svg',
    //   placeholder : 'Image'
    // },
    // {
    //   hoverText : 'Links',
    //   icon : './assets/svg/links.svg',
    //   placeholder : 'Links'
    // },
  ]
}];
  done = [];

  drop(event: CdkDragDrop<string[] | never[]>) {
      copyArrayItem(
          event.previousContainer.data,
          event.container.data,
          event.previousIndex,
          event.currentIndex
      );
  }
}
