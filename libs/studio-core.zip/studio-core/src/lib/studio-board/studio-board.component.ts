import {
    CdkDragDrop,
    CdkDropList,
    copyArrayItem,
    moveItemInArray,
} from '@angular/cdk/drag-drop';
import {
    AfterViewInit,
    Component,
    Input,
    TemplateRef,
    ViewChild,
} from '@angular/core';
import { DynamicTemplateService } from '@brahmos/shared-directives';
import { IBoardData } from '@brahmos/studio-modal';

@Component({
    selector: 'db-studio-board',
    templateUrl: './studio-board.component.html',
    styleUrls: ['./studio-board.component.scss'],
})
export class StudioBoardComponent implements AfterViewInit {
    @ViewChild(CdkDropList) doneList!: CdkDropList;

    public get connectedTo(): string[] {
        return this.getIdsRecursive(this.boardData).reverse();
    }
    boardData: IBoardData;

    constructor(private _dynamicTemplateService: DynamicTemplateService) {
        this.boardData = {
            uId: '0',
            child: [],
            tagName: 'div',
            hoverText: '',
            icon: '',
            placeholder: '',
        };
    }

    drop(event: CdkDragDrop<string[] | never[]>) {
        console.log(event);
        if (event.previousContainer === event.container) {
            moveItemInArray(
                event.container.data,
                event.previousIndex,
                event.currentIndex
            );
        } else {
            copyArrayItem(
                event.previousContainer.data,
                event.container.data,
                event.previousIndex,
                event.currentIndex
            );
        }
        console.log(this.boardData);
    }

    getTemplate(tagName: string): TemplateRef<unknown> | null {
        return this._dynamicTemplateService.getTemplate(tagName);
    }

    ngAfterViewInit(): void {
        console.log(this.doneList);
        this._dynamicTemplateService.dragList.push(this.doneList);
    }

    private getIdsRecursive(item: IBoardData): string[] {
        let ids = [item.uId];
        item.child?.forEach((childItem) => {
            ids = ids.concat(this.getIdsRecursive(childItem));
        });
        return ids;
    }
}
