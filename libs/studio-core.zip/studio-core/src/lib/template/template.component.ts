import { CdkDragDrop, CdkDropList } from '@angular/cdk/drag-drop';
import { AfterViewInit, Component, EventEmitter, Input, Output, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { DynamicTemplateService } from '@brahmos/shared-directives';
import { IBoardData } from '@brahmos/studio-modal';

@Component({
    selector: 'db-template',
    templateUrl: './template.component.html',
    styleUrls: ['./template.component.scss'],
})
export class TemplateComponent implements AfterViewInit {
  @Input() item!: IBoardData;
  @Input() connectedTo!: string[];
  @Input() parentIndex! : string;
  @Output() itemDrop: EventEmitter<CdkDragDrop<IBoardData>> = new EventEmitter<CdkDragDrop<IBoardData>>();
  @ViewChildren(CdkDropList) childmenu! : QueryList<CdkDropList>;
  constructor(private _templateService : DynamicTemplateService){

  }
  public onDragDrop(event: CdkDragDrop<IBoardData, IBoardData>): void {
    // this.itemDrop.emit(event);
    console.log('child',event,this.parentIndex)
  }

  ngAfterViewInit(): void {
    // console.log('childmenu' ,this.childmenu);
    this._templateService.dragList.push(...this.childmenu)
  }
}
