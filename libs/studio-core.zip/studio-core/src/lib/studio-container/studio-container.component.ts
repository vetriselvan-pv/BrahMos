
import { Component } from '@angular/core';

@Component({
    selector: 'db-studio-container',
    templateUrl: './studio-container.component.html',
    styleUrls: ['./studio-container.component.scss'],
})
export class StudioContainerComponent {


}
