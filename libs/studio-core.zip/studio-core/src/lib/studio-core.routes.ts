import { Routes } from '@angular/router';
import { StudioContainerComponent } from './studio-container/studio-container.component';

export const routes: Routes = [
  {
    path : '',
    component : StudioContainerComponent
  }
]
