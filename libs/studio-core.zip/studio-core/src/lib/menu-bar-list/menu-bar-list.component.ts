import { CdkDragExit, CdkDragMove, CdkDragStart, CdkDropList } from '@angular/cdk/drag-drop';
import { AfterViewInit, Component, Input, ViewChild } from '@angular/core';
import { IBoardData } from '@brahmos/studio-modal';
import { StudioBoardComponent } from '../studio-board/studio-board.component';
import { DynamicTemplateService } from '@brahmos/shared-directives';

@Component({
    selector: 'db-menu-bar-list',
    templateUrl: './menu-bar-list.component.html',
    styleUrls: ['./menu-bar-list.component.scss'],
})
export class MenuBarListComponent implements AfterViewInit{
    @Input() optionlist: IBoardData[] = [];
    doneList! : CdkDropList<unknown>[]

    constructor(private _templateService : DynamicTemplateService){}

    transferringItem: IBoardData | undefined = undefined;

    noReturnPredicate() {
        return false;
    }
    entered(e: unknown) {
        this.transferringItem = undefined;
    }

    exited(e: CdkDragStart<IBoardData>) {
        // console.log(e);
        this.transferringItem = e.source.data;
    }

    ngAfterViewInit(): void {
       this.doneList =  this._templateService.dragList
    }
}
